const quote = document.getElementById('quote');
const author= document.getElementById('author');
const button = document.querySelector('#button');
const button1 = document.querySelector('#button1');


const apiurl ='https://api.quotable.io/random'

button.addEventListener('click',()=>{
    console.log("hii");
    getone(apiurl);
  
})



async function getone(apiurl){
    const response = await fetch(apiurl);
    const data = await response.json();
    console.log(data);

    quote.innerHTML =`<h1 id="quote">${data.content}</h1>`
    author.innerHTML =`<p id="author">By - ${data.author}</p>`


}

function twitter(){
    window.open(`https://twitter.com/intent/tweet?text=quote.innerHTML`
  );
}

button1.addEventListener('click',()=>{
    twitter();
})